The files in this directory come from:
https://github.com/Kinovarobotics/ros_kortex/tree/noetic-devel/kortex_description