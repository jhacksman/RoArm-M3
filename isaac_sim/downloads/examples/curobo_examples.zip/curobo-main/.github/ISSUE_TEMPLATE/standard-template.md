---
name: Standard Template
about: standard issue template
title: ''
labels: ''
assignees: balakumar-s

---

If it’s not a bug, please use discussions: https://github.com/NVlabs/curobo/discussions

Please provide the below information in addition to your issue:

1. cuRobo installation mode (choose from [python, isaac sim, docker python, docker isaac sim]):
2. python version:
3. Isaac Sim version (if using): 


------
Issue Details
